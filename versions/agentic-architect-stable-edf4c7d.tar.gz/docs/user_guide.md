# User Guide

## Installation
1. Clone the repository
2. Run `docker-compose up --build`
3. Access the dashboard at `http://localhost:3000`

## Usage
1. Submit a CDC via the dashboard
2. Review the generated analysis, C4 diagrams, and code
3. Deploy the generated artifacts



![demo](global_demo.jpg)
