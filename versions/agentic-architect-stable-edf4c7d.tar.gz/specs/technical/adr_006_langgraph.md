# ADR 006: Usage of LangGraph for Agentic AI

**Status:** 

**Decider:** Fabien Furfaro

